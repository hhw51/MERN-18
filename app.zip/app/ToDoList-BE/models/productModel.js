const model = require("./index");

module.exports = {
    createProduct: () =>{
        
    }
}