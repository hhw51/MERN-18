const route = require("express").Router()
const {createUser,deleteUser,editUser,getUser}=require("../controllers/userController")
route.get("/create",createUser);
route.get("/delete",deleteUser);
route.get("/edit",editUser);
route.get("/get",getUser);

module.exports=route