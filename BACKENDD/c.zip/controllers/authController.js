const obj ={
    login:(req,res)=>{
        console.log(res)
        return res.send({
            message:"login API",
            data: req.query
        })
    },
    logout:(req,res)=>{
        return res.send({
            message:"logout API",
            data: req.body
        })
    },
    resetPassword:(req,res)=>{
        return res.send({
            message:"resetPassword API",
        })
    },
}
module.exports=obj;