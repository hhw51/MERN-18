const obj={
    attendance:(req,res)=>{
        return res.send({
            message:"attendance API"
        })
    },
        result:(req,res)=>{
        return res.send({
            message:"result API"
        })
    },
        courseMaterial:(req,res)=>{
        return res.send({
            message:"courseMaterial API"
        })
    },

}

module.exports=obj;