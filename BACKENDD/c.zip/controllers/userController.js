const obj ={
    createUser:(req,res)=>{
        return res.send({
            message:"createUser API",
        })
    },
    deleteUser:(req,res)=>{
        return res.send({
            message:"deleteUser API",
        })
    },
    editUser:(req,res)=>{
        return res.send({
            message:"editUser API",
        })
    }, 
    getUser:(req,res)=>{
        return res.send({
            message:"getUser API",
        })
    },
}
module.exports=obj;