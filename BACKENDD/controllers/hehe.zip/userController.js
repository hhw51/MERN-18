const joi = require("joi");
const userService = require("../services/userService");
const { response } = require("../app");
var grades = { Haris: 3.42, Ali: 3.11, Umar: 1.92 };
const createUserSchema = joi.object().keys({
  userName: joi.string().min(3).max(34).required(),
  password: joi.string().min(6).max(34).required(),
});
const obj = {
  createUser: async (req, res) => {
    try {
      const validatee = await createUserSchema.validateAsync(req.body);
      const user = await userService.createUser(validatee);

      if (user.error) {
        console.log(user.error);

        return res.send({
          error: user.error,
        });
      }
      return res.send({ response: user.response });
    } catch (error) {
      console.log(error);
      return res.send({ error: error });
    }
  },
  getAllUser: async (req, res) => {
    try {
      const users = await userService.getAllUser();
      if (users.error) {
        return res.send({
          error: users.error,
        });
      }
      return res.send({
        response: users.response,
      });
    } catch (error) {
      return res.send({ error: error });
    }
  },
  deleteUser: (req, res) => {
    return res.send({
      message: "deleteUser API",
    });
  },
  editUser: (req, res) => {
    return res.send({
      message: "editUser API",
    });
  },
  getUser: (req, res) => {
    return res.send({
      message: "getUser API",
    });
  },  updateUser: (req, res) => {
    return res.send({
      message: "UpdateUser API",
    });
  },
};
module.exports = obj;
